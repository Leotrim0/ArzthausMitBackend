from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class Doctor(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    dob = models.TextField(blank=True)
    gender = models.TextField(blank=True)
    address = models.TextField(blank=True)
    city = models.TextField(blank=True)
    postal_code = models.TextField(blank=True)
    phone_number = models.TextField(blank=True)
    picture = models.ImageField(upload_to='doctor_pictures')
    short_biography = models.TextField(blank=True)
    status = models.TextField(blank=True)


class Patient(models.Model):
    first_name = models.TextField(blank=True)
    last_name = models.TextField(blank=True)
    email = models.TextField(blank=True)
    dob = models.TextField(blank=True)
    gender = models.TextField(blank=True)
    address = models.TextField(blank=True)
    city = models.TextField(blank=True)
    zip_code = models.TextField(blank=True)
    phone_number = models.TextField(blank=True)
    status = models.TextField(blank=True)
    # picture = models.ImageField(upload_to='patient_pictures')

