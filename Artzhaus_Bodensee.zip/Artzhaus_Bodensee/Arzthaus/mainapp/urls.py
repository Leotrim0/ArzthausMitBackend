from django.urls import path
from . import views

urlpatterns = [
   path('', views.home, name='home'),
   path('doctors', views.doctors, name='doctors'),
   path('add_doctor', views.add_doctor, name='add_doctor'),
   path('delete_doctor/<int:doctor_id>', views.delete_doctor, name='delete_doctor'),
   path('doctor_profile/<int:doctor_id>', views.doctor_profile, name='doctor_profile'),
   path('patients', views.patients, name='patients'),
   path('add_patient', views.add_patient, name='add_patient'),
   path('patients', views.patients, name='patients'),
   path('delete_patient/<int:patient_id>', views.delete_patient, name='delete_patient'),
   path('appointments', views.appointments, name='appointments'),
   path('schedule', views.schedule, name='schedule'),
   path('departments', views.departments, name='departments'),
   path('employees', views.employees, name='employees'),
   path('leaves', views.leaves, name='leaves')
]