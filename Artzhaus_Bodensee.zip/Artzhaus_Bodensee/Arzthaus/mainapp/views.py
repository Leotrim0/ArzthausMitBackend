from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required(login_url='login')
def home(request):
    return render(request, 'index-2.html')

@login_required(login_url='login')
def doctors(request):
    context = {
        'doctor_set': Doctor.objects.all()
    }
    return render(request, 'doctors.html', context)

@login_required(login_url='login')
def add_doctor(request):
    if request.method == 'POST':
        user = User()
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        user.username = request.POST.get('username')
        user.email = request.POST.get('email')
        user.set_password(request.POST.get('password'))
        user.save()

        doctor = Doctor()
        doctor.user = user
        doctor.dob = request.POST.get('dob')
        doctor.gender = request.POST.get('gender')
        doctor.address = request.POST.get('address')
        doctor.city = request.POST.get('city')
        doctor.postal_code = request.POST.get('postal_code')
        doctor.phone_number = request.POST.get('phone_number')
        doctor.picture = request.FILES.get('picture')
        doctor.status = request.POST.get('status')
        doctor.short_biography = request.POST.get('short_biography')
        doctor.save()

        return redirect('doctors')
    
    return render(request, 'add-doctor.html')


@login_required(login_url='login')
def delete_doctor(request, doctor_id):
    doctor = Doctor.objects.get(pk=doctor_id)
    doctor.delete()

    return redirect('doctors')

@login_required(login_url='login')
def doctor_profile(request, doctor_id):
    context = {
        'doctor' : Doctor.objects.get(pk=doctor_id)
    }

    return render(request, 'profile.html', context)

@login_required(login_url='login')
def patients(request):
    patient_set = []
    for item in Patient.objects.all():
        try:
            item.age = calculate_age(item.dob)
        except:
            pass
        patient_set.append(item)
    context = {
        'patient_set': patient_set
    }

    return render(request, 'patients.html', context)

@login_required(login_url='login')
def add_patient(request):
    if request.method == 'POST':
        p = Patient()
        p.first_name = request.POST.get('first_name')
        p.last_name = request.POST.get('last_name')
        p.email = request.POST.get('email')

        p.dob = request.POST.get('dob')
        p.gender = request.POST.get('gender')
        p.address = request.POST.get('address')
        p.city = request.POST.get('city')
        p.zip_code = request.POST.get('zip_code')
        p.phone_number = request.POST.get('phone_number')
        # p.picture = request.FILES.get('picture')
        p.status = request.POST.get('status')

        p.save()

        return redirect('patients')

    else:
        return render(request, 'add-patient.html')

@login_required(login_url='login')
def delete_patient(request, patient_id):
    patient = Patient.objects.get(pk=patient_id)
    patient.delete()
    return redirect('patients')


@login_required(login_url='login')
def appointments(request):
    return render(request, 'appointments.html')

@login_required(login_url='login')
def schedule(request):
    return render(request, 'schedule.html')



@login_required(login_url='login')
def departments(request):
    return render(request, 'departments.html')




@login_required(login_url='login')
def employees(request):
    return render(request, 'employees.html')



@login_required(login_url='login')
def leaves(request):
    return render(request, 'leaves.html')


# Helpers
from datetime import datetime
def calculate_age(date_of_birth):
    # Assuming date_of_birth is a string in the format 'MM/DD/YYYY'
    dob = datetime.strptime(date_of_birth, '%m/%d/%Y')
    today = datetime.now()
    
    # Calculate the difference in years
    age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    
    return age